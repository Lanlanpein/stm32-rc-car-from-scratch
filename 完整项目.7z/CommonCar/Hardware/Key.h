#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);
uint16_t Get_Keynum(void);

#endif
