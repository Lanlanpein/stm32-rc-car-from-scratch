#ifndef __WIFI_H
#define __WIFI_H

void WiFi_Init(void);
uint16_t Get_WIFI(void);

#endif
